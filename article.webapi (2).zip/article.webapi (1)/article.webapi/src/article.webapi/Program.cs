using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using System;
using System.IO;


namespace NetCoreWebapi4
{
    public class Program
    {
        private static IConfiguration _configuration { get; set; }
        public static int Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                // Loading appsettings.json is only here to enable local dev:
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                // this line is where we mount the config map in Openshift, thus loading configuration:
                .AddJsonFile("/opt/app-root/app/appconfig.json", optional: true, reloadOnChange: true)
                // You can of course use Environment variables for configuration as well:
                .AddEnvironmentVariables();
            _configuration = builder.Build();

            var applicationName = _configuration["AppSettings:ApplicationName"];

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .Enrich.FromLogContext()
                .WriteTo.Console()
                .CreateLogger();

            try
            {
                Log.Information("Starting web host");
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Host terminated unexpectedly");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }
            return 0;

        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    // webBuilder.UseKestrel();
                    //webBuilder.ConfigureKestrel(serverOptions =>
                    //{
                    //});
                    //webBuilder.UseIISIntegration();
                    webBuilder.UseConfiguration(_configuration);
                    webBuilder.UseStartup<Startup>();
                    webBuilder.UseContentRoot(Directory.GetCurrentDirectory());
                    webBuilder.UseWebRoot("wwwroot");
                });
    }
}
