﻿using Microsoft.AspNetCore.Mvc;
using Operational.Implementation;

namespace webapi
{
    /// <summary>
    /// Startup controller
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// Startup entry point
        /// </summary>
        /// <returns></returns>
        [Route("")]
        [Route("Home")]
        [Route("Home/Index")]
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Environment = $"{ConfigManager.TestConfig} ON {ConfigManager.TestConfig}";
            return View();
        }
    }
}
