﻿using Facade.RemoveMeTemplateExample;
using Facade.RemoveMeTemplateExample.ClubExample;
using Microsoft.AspNetCore.Mvc;
using Model.Example;
using Serilog;
using webapi.Filters;
using System.Collections.Generic;
using System.Threading.Tasks;
using Facade.Articles;
using Model;

namespace NetCoreWebapi4.Controllers
{
    /// <summary>
    /// Template controller
    /// </summary>
    /// 

    [Route("api/v{version:apiVersion}/articles")]
    [ApiController]
    [ApiKeyAuth]
    public class TemplateController : ControllerBase
    {
        public IArticleFacade ArticleFacade { get; }

        public TemplateController(IArticleFacade articleFacade)
        {
            ArticleFacade = articleFacade;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns> 
        // 
        [HttpGet()]
        public async Task<ActionResult<IEnumerable<ArticleModel>>> Getarticels()
        {
            var resp = await RunAsync(async () =>
            {
                // Example log, use serilog
                Log.Information("Articles log");

                // Example for awaitable classes
                return await ArticleFacade.GetAll();
            });
            return MapValueToResponse(resp.Item1, resp.Item2, "GET");
        }

        [HttpPost]
        public async Task<ActionResult<bool>> AddNewArticle([FromBody] ArticleModel articleModel)
        {
            var resp = await RunAsync(async () =>
            {
                // Example for awaitable classes
                return await ArticleFacade.AddNewArticle(articleModel);
            });
            return MapValueToResponse(resp.Item1, resp.Item2, "POST", "");

        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteArticle(int id)
        {
            var resp = await RunAsync(async () =>
            {
                // Example for awaitable classes
                return await ArticleFacade.DeleteArticle(id);
            });
            return MapValueToResponse(resp.Item1, resp.Item2, "DELETE", "");

        }
    }
}
