﻿using Microsoft.AspNetCore.Mvc;
using Operational.Exceptions;
using Operational.Validations;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace NetCoreWebapi4.Controllers
{
    public class ControllerBase : Microsoft.AspNetCore.Mvc.ControllerBase
    {
        /// <summary>
        /// This member runs the callback ignoring exceptions, it logs the error and returns to caller with the default value 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="lambda"></param>
        /// <param name="callerMethodName"></param>
        /// <returns></returns>
        public async Task<Tuple<T, OperationStatus>> SilentRunAsync<T>(Func<Task<T>> lambda, [CallerMemberName] string callerMethodName = "")
        {
            try
            {
                var result = await RunAsync(lambda, callerMethodName);
                return result;
            }
            catch (Exception)
            {
                return default;
            }
        }
        public async Task<Tuple<T, OperationStatus>> RunAsync<T>(Func<Task<T>> lambda, [CallerMemberName] string callerMethodName = "")
        {
            DateTime startTime = DateTime.UtcNow;
            var operationStatus = new OperationStatus();
            try
            {
                T result = await lambda();
                operationStatus.Success = true;
                return new Tuple<T, OperationStatus>(result, operationStatus);
            }
            catch (CustomValidationException validationExp)
            {
                operationStatus.HttpStatusCode = HttpStatusCode.UnprocessableEntity;
                operationStatus.ValidationErrors = validationExp.ValidationErrors;
                Log.Error(validationExp, "");
                return new Tuple<T, OperationStatus>(default, operationStatus);
            }
            catch (HttpResponseException e)
            {
                operationStatus.HttpStatusCode = (HttpStatusCode)e.Status;
                // Ska vi skicka hela felmedelandet till klienten?
                // operationStatus.ClientMessage = e.Message;
                Log.Error(e, "");
                return new Tuple<T, OperationStatus>(default, operationStatus);
            }
            catch (Exception e)
            {
                var errorCode = Guid.NewGuid().ToString();
                Log.Error(e, errorCode);
                throw new InternaServerErrorNoStackTraceException($"Internal server error. Check the log files or contact the api-developer ERRORCODE: {errorCode}");
            }
            finally
            {
                var now = DateTime.UtcNow;
                var duration = (int)(now - startTime).TotalMilliseconds;
                if (duration > 500)
                {
                    Log.Warning("Anrop mot tjänsten {callerMethodName} tog längre tid än väntat, {durationMs} ms", callerMethodName, duration);
                }
            }
        }

        public ActionResult<T> MapValueToResponse<T>(T result, OperationStatus operationStatus, string verb, string uri = null)
        {
            if (operationStatus.Success)
            {
                if (verb == "POST")
                {
                    return Created(uri, result);
                }
                else if (verb == "PUT")
                {
                    return Ok(result); // TODO: Kolla För PUT return
                }
                else if (verb == "DELETE")
                {
                    if (result is bool deleted && deleted == true)
                    {
                        return NoContent();
                    }
                    return NotFound("Could not delete, object is not found");
                }
                else if (verb == "GET")
                {
                    if (result == null)
                    {
                        return NotFound();
                    }
                    else if (IsEmptyList(result))
                    {
                        return NoContent();
                    }
                    else
                    {
                        return Ok(result);
                    }
                }
                else
                {
                    return BadRequest();
                }
            }
            else
            {
                // TODO: Fixa andra statuser
                switch (operationStatus.HttpStatusCode)
                {
                    case HttpStatusCode.Unauthorized:
                        return Unauthorized("Not authorized or token is not valid");
                    case HttpStatusCode.UnprocessableEntity: // Valideringsfel, måste ha meddelande varför
                        return UnprocessableEntity(new { operationStatus?.ValidationErrors });
                    default:
                        return BadRequest();
                }
            }
        }
        private static bool IsEmptyList<T>(T t)
        {
            return t is IEnumerable<object> casted && !casted.Any();
        }

    }

    public class OperationStatus
    {
        public bool Success { get; set; }
        public HttpStatusCode? HttpStatusCode { get; set; }
        public string ClientMessage { get; set; }
        public IEnumerable<ValidationError> ValidationErrors { get; set; }
    }
}
