﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Threading.Tasks;

namespace NetCoreWebapi4
{
    /// <summary>
    /// Lägger till health checks för applikationen.
    /// </summary>
    internal static class HealthChecks
    {
        // Registrerar alla health checks.
        //public static void AddHealthChecks(this IServiceCollection services)
        //{
        //	services.AddHealthChecks();
        //}

        /// <summary>
        /// Lägger till middleware för health checks, både för readiness och liveness.
        /// </summary>
        public static void UseHealthChecks(this IApplicationBuilder app)
        {
            app.UseHealthChecks("/healthcheck/ready", new HealthCheckOptions()
            {
                Predicate = (check) => check.Tags.Contains("ready"),
                ResponseWriter = WriteResponse
            });

            app.UseHealthChecks("/healthcheck/live", new HealthCheckOptions()
            {
                Predicate = (check) => check.Tags.Contains("live"),
                ResponseWriter = WriteResponse
            });
        }

        /// <summary>
        /// Formaterar och returnerar health check rapporten till klienten.
        /// </summary>
        private static Task WriteResponse(HttpContext httpContext,
            HealthReport report)
        {
            httpContext.Response.ContentType = "application/json";

            var jsonSerializerSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                Formatting = Formatting.Indented,
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            jsonSerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter(new CamelCaseNamingStrategy()));

            var json = JsonConvert.SerializeObject(report, jsonSerializerSettings);

            return httpContext.Response.WriteAsync(json);
        }
    }
}
