using DataAccess.Example;
using Facade.RemoveMeTemplateExample;
using Facade.RemoveMeTemplateExample.ClubExample;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Model.Profiles;
using NetCoreWebapi4.Filters;
using Operational.Configuration.core;
using Serilog;
using Operational.Implementation;
using webapi.Filters;
using System;
using System.IO;
using System.Reflection;
using DataAccess.Articles;
using Facade.Articles;
using DataAccess;

namespace NetCoreWebapi4
{
    public class Startup
    {
        readonly string TemplatePolicyAllowOrigins = "TemplatePolicyAllowOrigins ";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            SetConfiguration(services);

            services.AddSingleton(new ConfigManager(Configuration));


            // configure basic authentication 
            services.AddAuthentication("BasicAuthentication")
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);


            //This is an example using Add mapper profiles from Model
            services.AddAutoMapper(typeof(TemplateProfile));

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .Enrich.FromLogContext()
                .WriteTo.File(ConfigManager.LogFileName)
                .CreateLogger();
            Log.Information("Log local");

            // Register all dependencies
            RegisterDependencies(services);

            services.AddMvc(option => option.EnableEndpointRouting = false);
            services.AddHttpClient();

            services.AddApiVersioning(opt =>
            {
                opt.AssumeDefaultVersionWhenUnspecified = true;
                opt.DefaultApiVersion = new ApiVersion(1, 0);
                opt.ReportApiVersions = true;
                //opt.Conventions.Controller<TemplateController>()
                //.HasApiVersion(new ApiVersion(1, 0));
            });
            services.AddVersionedApiExplorer(options => options.GroupNameFormat = "'v'VVV");

            services.AddCors(o => o.AddPolicy(TemplatePolicyAllowOrigins, builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

            services.AddSwaggerGen(options =>
            {
                var headerKey = Configuration.GetValue<string>("ApiKeySettings:HeaderKey");
                options.AddSecurityDefinition(headerKey, new OpenApiSecurityScheme
                {
                    Description = "Api key needed for test use test123",
                    In = ParameterLocation.Header,
                    Name = headerKey,
                    Type = SecuritySchemeType.ApiKey
                });

                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = headerKey,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = headerKey
                            },
                         },
                         Array.Empty<string>()
                     }
                });

                options.SwaggerDoc("v1", new OpenApiInfo { Title = Configuration["AppSettings:ApplicationName"], Version = "v1" });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });

            services.AddHealthChecks();

            services.AddControllers().AddNewtonsoftJson();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(TemplatePolicyAllowOrigins);

            app.UseHealthChecks();
            app.UseApiKey();
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", Configuration["AppSettings:ApplicationName"]);
            });

            //app.UseRequestLogger();
            //app.UseUnhandledErrorsLogger();


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseStaticFiles();
            app.UseMvc(routes =>
            {
                routes.MapRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private void SetConfiguration(IServiceCollection services)
        {
            var config = new BasicAuthConfiguration();
            Configuration.Bind("BasicAuth", config);
            services.AddSingleton(config);
        }

        private static void RegisterDependencies(IServiceCollection services)
        {
            // You can use reflection to register dependencies

            // Examples start -->
            services.AddScoped<IMsSqlDataClient, MsSqlDataClient>();

            services.AddScoped<IFacadeExample, FacadeExample>();
            services.AddScoped<IClubNoEFExampleData, ClubNoEFExampleData>();
            services.AddScoped<IClubInfoNoEFExampleFacade, ClubInfoNoEFExampleFacade>();


            services.AddScoped<IArticleClient, ArticleClient>();
            services.AddScoped<IArticleFacade, ArticleFacade>();


            // Examples end


        }
    }
}
