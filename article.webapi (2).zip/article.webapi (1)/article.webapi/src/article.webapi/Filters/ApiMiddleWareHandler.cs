﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Threading.Tasks;

namespace NetCoreWebapi4.Filters
{
    public class ApiMiddleWareHandler
    {
        public RequestDelegate Next { get; }

        //public IConfiguration Configuration { get; }
        public ApiMiddleWareHandler(RequestDelegate next)
        {
            Next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Method == "OPTIONS")
            {
                context.Response.Headers.Add("Access-Control-Allow-Origin", new[] { (string)context.Request.Headers["Origin"] });
                context.Response.Headers.Add("Access-Control-Allow-Headers", new[] { "Origin, X-Requested-With, Content-Type, Accept", "X-JWT-Assertion" });
                context.Response.Headers.Add("Access-Control-Allow-Methods", new[] { "GET, POST, PUT, DELETE, OPTIONS" });
                context.Response.Headers.Add("Access-Control-Allow-Credentials", new[] { "true" });
                context.Response.Headers.Add("Content-Type", new[] { "application/json" });
                context.Response.ContentLength = 0;
                context.Response.StatusCode = 200;
                await context.Response.WriteAsync("");
            }

            var beginInvokeTime = DateTime.UtcNow;
            await Next.Invoke(context);
            var endInvokeTime = DateTime.UtcNow;
            var timeDiff = (endInvokeTime - beginInvokeTime).Milliseconds;
            var operation = context.Request.Path.Value;
            var respStatusCode = context?.Response?.StatusCode;
            Log.Logger.Information($"Arop till {operation} tog: {timeDiff} millisekunder och retunerar statuskod: {respStatusCode}");

        }
    }
    public static class OptionsMiddlewareExtensions
    {
        public static IApplicationBuilder UseOptions(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ApiMiddleWareHandler>();
        }
    }
}
