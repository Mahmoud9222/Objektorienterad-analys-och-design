﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webapi.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class ApiKeyAuthAttribute : Attribute, IAsyncActionFilter
    {

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var configuration = context.HttpContext.RequestServices.GetRequiredService<IConfiguration>();

            var headerKey = configuration.GetSection("ApiKeySettings:HeaderKey").Get<string>();

            if (!context.HttpContext.Request.Headers.TryGetValue(headerKey, out var apiKeyIn))
            {
                context.Result = new UnauthorizedResult();
                return;
            }


            var values = configuration.GetSection("ApiKeySettings:Keys").Get<List<string>>();

            if (values.FirstOrDefault(k => k == apiKeyIn) == null)
            {
                context.Result = new UnauthorizedResult();
                return;
            }
            await next();
        }
    }
}
