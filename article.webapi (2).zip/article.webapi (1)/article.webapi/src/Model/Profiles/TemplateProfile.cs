﻿using AutoMapper;

namespace Model.Profiles
{
    public class TemplateProfile : Profile
    {
        public TemplateProfile()
        {

        }
    }

}
