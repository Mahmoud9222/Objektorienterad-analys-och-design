﻿using Newtonsoft.Json;

namespace Model.Example
{
    public class ClubInfoExampleModel
    {

        public int Id { get; set; }

        [JsonProperty("club_namn")]
        public string Name { get; set; }
    }
}
