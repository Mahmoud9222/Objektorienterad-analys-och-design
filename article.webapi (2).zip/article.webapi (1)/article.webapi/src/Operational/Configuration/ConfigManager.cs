using Microsoft.Extensions.Configuration;

namespace Operational.Implementation
{
    /// <summary>
    /// Klass inneh�llande metoder f�r att h�mta ut applicationskonfigurering specifikt f�r AS.Web
    /// </summary>
    public class ConfigManager : ConfigReader, IConfigManager
    {
        public ConfigManager(IConfiguration configuration) : base(configuration) { }

        public static string TestConfig => GetString("AppSettings:testchildsection");
        public static string EtmConnection => GetString("ConnectionStrings:EtmConnectionString");

        public static bool CacheEnabled => GetBoolean("AppSettings:CacheEnabled");
        public static int CacheTimeOutMinutes => GetInt("AppSettings:CacheTimeOutMinutes");


        public static string LogFileName => GetString("Logging:logFile:filePath");

        // Testable fields
        //public string ServiceUserName { get { return GetString(""); } set { ServiceUserName = value; } }
        //public string ServicePassword { get { return GetString(""); } set { ServicePassword = value; } }
        //public string ServiceId { get { return GetString(""); } set { ServiceId = value; } }
    }
}