﻿
namespace Operational.Implementation
{
    public interface IConfigManager
    {
        // If the configuration  is testable, add it here and override it in the test class
        // If the configuration is fixed, or will not change the logic to the code or we do not need to test trhen add it as static configration in the 
        // implementation file ConfigManager
        //public string ServiceUserName { get; set; }
        //public string ServicePassword { get; set; }
        //public string ServiceId { get; set; }

    }
}
