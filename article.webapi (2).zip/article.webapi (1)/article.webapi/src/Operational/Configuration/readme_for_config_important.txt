﻿
The files ConfigManager, ConfigReader and IConfigManager are there to help you if you don't want to create a configuration class for each section, so for simple values you can add directly to config manager.
If you do not want to test the value add it only on the ConfigManager as static variable, if you need to test, it is advicable to add it to the interface class IConfigManager as member.


If you need a config section any way, you can to check the file BasicAuthConfiguration in folder core as example.
It is usually a better practice to put every class in own file, but for configuration files maybe it is better to put all clases inside the same file to have a clearer piture of the configuration
Do not forget to update the Startup.cs file för each section you add.



