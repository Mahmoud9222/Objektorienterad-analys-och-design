﻿using Microsoft.Extensions.Configuration;
using System;

namespace Operational.Implementation
{
    /// <summary>
    /// Hjälpklass som hämtar värden från från .Net:s inbyggda konfigurationsfiler
    /// (web.config och App.config)
    /// </summary>
    public abstract class ConfigReader
    {
        private static IConfiguration _configuration;
        public ConfigReader(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Hämtar ut strängvärde från konfigurationsfilen
        /// </summary>
        /// <param name="key">Appsettingsnyckel</param>
        /// <remarks>Om nyckel saknas returneras null</remarks>
        /// <returns>strängvärde</returns>
        protected static string GetString(string key)
        {
            return GetString(key, null);
        }

        /// <summary>
        /// Hämtar ut strängvärde från konfigurationsfilen
        /// </summary>
        /// <param name="key">Appsettingsnyckel</param>
        /// <param name="defaultstring">Önskat defaultvärde då nyckel saknas i konfigurationsfilen</param>
        /// <remarks>Om nyckel saknas returneras null</remarks>
        /// <returns>strängvärde</returns>
        protected static string GetString(string key, string defaultstring)
        {
            string value = _configuration[key];
            if (value == null)
            {
                return defaultstring;
            }

            return value;
        }

        /// <summary>
        /// Hämtar ut boolskt värde från konfigurationsfilen
        /// </summary>
        /// <param name="key">Appsettingsnyckel</param>
        /// <remarks>Om nyckel saknas returneras false</remarks>
        /// <returns>boolskt värde</returns>
        protected static bool GetBoolean(string key)
        {
            bool value = Convert.ToBoolean(GetString(key));

            return value;
        }

        /// <summary>
        /// Hämtar ut en integer från konfigurationsfilen
        /// </summary>
        /// <param name="key">Appsettingsnyckel</param>
        /// <remarks>Om nyckel saknas returneras 0</remarks>
        /// <returns>integervärde</returns>
        protected static int GetInt(string key)
        {
            return Convert.ToInt32(GetString(key));
        }

        /// <summary>
        /// Hämtar ut ett datum från konfigurationsfilen
        /// </summary>
        /// <param name="key"></param>
        /// <returns>ett datetime-värde</returns>
        /// <remarks>Om nyckeln inte kan parsas till ett datetime kastas ett exception</remarks>
        protected static DateTime GetDateTime(string key)
        {
            return DateTime.Parse(GetString(key));
        }

        /// <summary>
        /// Hämtar ut ett timespan från en sträng (hour:minute)
        /// </summary>
        /// <param name="timespanConfigName"></param>
        /// <returns>Ett timespan</returns>
        protected static TimeSpan GetTimespan(string timespanConfigName)
        {
            string startTid = GetString(timespanConfigName);

            string[] test = startTid.Split(':');

            int hours = int.Parse(test[0]);

            int minutes = int.Parse(test[1]);

            return new TimeSpan(hours, minutes, 0);
        }

    }
}
