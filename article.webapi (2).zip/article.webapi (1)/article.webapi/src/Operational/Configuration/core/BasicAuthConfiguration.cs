﻿using System.Collections.Generic;

namespace Operational.Configuration.core
{
    public class BasicAuthConfiguration
    {
        public List<UsersConfig> Users { get; set; } = new List<UsersConfig>();
    }

    // every class shoud be in own files, but for configuration it is more clearer to have in the same file
    public class UsersConfig
    {
        public string Name { get; set; }
        public string Password { get; set; }

        public string ServiceId { get; set; }
        public List<RolesConfig> Roles { get; set; } = new List<RolesConfig>();
    }

    public class RolesConfig
    {
        public string Name { get; set; }
    }

}
