﻿
namespace Operational.Validations
{
    public class ValidationError
    {
        public string PropertyName { get; set; }
        public string ErrorCode { get; set; }
        public string ActualValue { get; set; }
        public string ErrorMessage { get; set; }
    }
}
