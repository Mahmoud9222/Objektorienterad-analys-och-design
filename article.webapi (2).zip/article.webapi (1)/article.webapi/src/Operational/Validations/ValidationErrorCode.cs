﻿using System.ComponentModel;

namespace Operational.Validations
{
    public enum ValidationErrorCode
    {
        [Description("FIELD_REQUIRED")]
        FIELD_REQUIRED,
        [Description("INVALID_CHARACTERS")]
        INVALID_CHARACTERS,
        [Description("INVALID_LENGTH")]
        INVALID_LENGTH,
        [Description("INVALID_DATE")]
        INVALID_DATE,
        [Description("ACTION_NOTALLOWED")]
        ACTION_NOTALLOWED
    }
}
