﻿using System;
using System.Net.Http;

namespace Operational.Exceptions
{
    public class HttpResponseException : Exception
    {
        public HttpResponseException(HttpResponseMessage reponseMessage)
        {
            ReponseMessage = reponseMessage;
        }
        public HttpResponseMessage ReponseMessage { get; }
        public int Status { get; set; } = 500;

        public object Value { get; set; }
    }
}
