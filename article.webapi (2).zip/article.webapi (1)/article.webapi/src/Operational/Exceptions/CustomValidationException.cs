﻿using Operational.Extensions;
using Operational.Validations;
using System;
using System.Collections.Generic;
using System.Text;

namespace Operational.Exceptions
{
    [Serializable]
    public class CustomValidationException : Exception
    {
        public IEnumerable<ValidationError> ValidationErrors { get; set; }
        public CustomValidationException() { }
        public CustomValidationException(IEnumerable<ValidationError> validationErrors) { ValidationErrors = validationErrors; }
        public CustomValidationException(string message) : base(message)
        {
            ValidationErrors = new List<ValidationError>
            {
                new ValidationError
                {
                    ActualValue = "",
                    ErrorCode = ValidationErrorCode.ACTION_NOTALLOWED.ToDescription(),
                    ErrorMessage = message,
                    PropertyName = ""
                }
            };
        }
        public CustomValidationException(string message, Exception innerExp) : base(message, innerExp) { }
    }
}
