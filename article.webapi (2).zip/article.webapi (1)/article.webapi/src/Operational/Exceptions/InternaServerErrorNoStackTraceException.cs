﻿using System;

namespace Operational.Exceptions
{
    public class InternaServerErrorNoStackTraceException : Exception
    {
        public InternaServerErrorNoStackTraceException(string message) : base(message) { } //constructor

        public override string StackTrace
        {
            get { return ""; }
        }
    }
}
