﻿using Operational.Implementation;
using System;
using System.Runtime.Caching;


namespace Operational.Performance
{
    ///
    public class RestClientCacheManager
    {

        private static readonly ObjectCache Cache = MemoryCache.Default;

        public static bool Contains(string key)
        {
            return ConfigManager.CacheEnabled && Cache.Contains(key);
        }

        public static object Get(string key)
        {
            if (ConfigManager.CacheEnabled)
            {
                return Cache.Get(key);
            }
            return null;
        }

        public static void Remove(string key)
        {
            Cache.Remove(key);
        }

        public static void Set(string key, object value, double? minutes = null)
        {
            if (minutes == null)
            {
                minutes = ConfigManager.CacheTimeOutMinutes;
            }
            if (minutes < 0.01)  // About 0.6 sec
            {
                return;
            }

            var cacheItemPolicy =
                new CacheItemPolicy
                {
                    AbsoluteExpiration = DateTimeOffset.Now.AddMinutes((double)minutes)
                };

            Cache.Set(key, value, cacheItemPolicy);
        }
    }
}
