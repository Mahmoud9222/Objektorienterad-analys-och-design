﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace DataAccess
{
    public interface IMsSqlDataClient
    {
        Task<T> QueryFirstAsync<T, U>(string sql, U parameters, string connectionString = null);
        Task<T> QueryFirstOrDefaultAsync<T, U>(string sql, U parameters, string connectionString = null);
        Task<List<T>> LoadData<T, U>(string sql, U parameters, string connectionString = null);
        Task<int> ExecuteDataAsync<T>(string sql, T parameters, CommandType commandType = CommandType.Text, string connectionString = null);
        Task<Tout> ExecuteScalarDataAsync<T, Tout>(string sql, T parameters, CommandType commandType = CommandType.Text, string connectionString = null);
    }
}
