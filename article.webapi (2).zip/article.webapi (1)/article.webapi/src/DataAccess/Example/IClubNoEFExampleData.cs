﻿using Model.Example;
using System.Collections.Generic;

namespace DataAccess.Example
{
    public interface IClubNoEFExampleData
    {
        IEnumerable<ClubInfoExampleModel> GetAll();
    }
}
