﻿using Model.Example;
using Operational.Implementation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess.Example
{
    public class ClubNoEFExampleData : IClubNoEFExampleData
    {
        public IEnumerable<ClubInfoExampleModel> GetAll()
        {
            List<ClubInfoExampleModel> clubModel = new();

            using (SqlConnection connection = new(ConfigManager.EtmConnection))
            {
                connection.Open();
                using SqlCommand cmd = new(Sql, connection);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 300;
                using SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    clubModel.Add(new ClubInfoExampleModel
                    {
                        Id = Convert.ToInt32(reader.GetValue(0)),
                        Name = reader.GetValue(1).ToString()
                    });
                    ;
                }
            }

            return clubModel;
        }

        public static string Sql => @"SELECT club_id, clubname FROM club WITH (NOLOCK)";


    }
}
