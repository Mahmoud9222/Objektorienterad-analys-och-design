﻿using Dapper;
using Model;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using static Dapper.SqlMapper;

namespace DataAccess.Articles
{
    public class ArticleClient : IArticleClient
    {
        public IMsSqlDataClient MsSqlDataClient { get; }

        public ArticleClient(IMsSqlDataClient msSqlDataClient)
        {
            MsSqlDataClient = msSqlDataClient;
        }
        public async Task<IEnumerable<ArticleModel>> GetAll()
        {
            var articles = await MsSqlDataClient.LoadData<ArticleModel, dynamic>(ArticlesSelectSql, new {});
            return articles;
        }

        public async Task<bool> AddNewArticle(ArticleModel articleModel)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@Code", dbType: DbType.String, value: articleModel.Code, direction: ParameterDirection.Input, size: 30);
            dynamicParameters.Add("@Description", dbType: DbType.String, value: articleModel.Description, direction: ParameterDirection.Input, size: 200);
            dynamicParameters.Add("@CreatedBy", dbType: DbType.String, value: articleModel.CreatedBy, direction: ParameterDirection.Input, size: 30);
            dynamicParameters.Add("@Created", dbType: DbType.DateTime, value: articleModel.Created, direction: ParameterDirection.Input);
            dynamicParameters.Add("@UpdateBy", dbType: DbType.String, value: articleModel.UpdatedBy, direction: ParameterDirection.Input, size: 30);
            dynamicParameters.Add("@Updated", dbType: DbType.DateTime, value: articleModel.Updated, direction: ParameterDirection.Input);

            int rowsInserted = await MsSqlDataClient.ExecuteDataAsync<object>(ArticlesAddSql, dynamicParameters);
            return rowsInserted > 0;

        }

        public async Task<bool> UpdateArticle(ArticleModel articleModel)
        {
            int rowsInserted = await MsSqlDataClient.ExecuteDataAsync<object>(ArticlesAddSql, null);

            throw new System.NotImplementedException();
        }

        public async Task<bool> DeleteArticle(int articleid)
        {
            int rowsInserted = await MsSqlDataClient.ExecuteDataAsync<object>(@"DELETE FROM Article where id = @articleid", new { articleid });
            return true;

        }

        private static string ArticlesAddSql => @"
               INSERT INTO Article(Code, Description, CreatedBy, Created, UpdateBy, Updated) VALUES (@Code, @Description, @CreatedBy, @Created, @UpdateBy, @Updated)
        ";
        private static string ArticlesSelectSql => @"
                SELECT 
                    Id, Code, Description, CreatedBy, Created, UpdateBy, Updated
                FROM Article
        ";

    }
}
