﻿using Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DataAccess.Articles
{
    public interface IArticleClient
    {
        Task<IEnumerable<ArticleModel>> GetAll();
        Task<bool> AddNewArticle(ArticleModel articleModel);
        Task<bool> UpdateArticle(ArticleModel articleModel);
        Task<bool> DeleteArticle(int articleid);
    }
}
