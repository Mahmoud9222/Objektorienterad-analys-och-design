﻿using Dapper;
using Operational.Implementation;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;


//TODO: Copy to Template
namespace DataAccess
{
    public class MsSqlDataClient : IMsSqlDataClient
    {
        public async Task<T> QueryFirstAsync<T, U>(string sql, U parameters, string connectionString = null)
        {
            using IDbConnection connection = new SqlConnection(!string.IsNullOrWhiteSpace(connectionString) ? connectionString : ConfigManager.EtmConnection);
            var result = await connection.QueryFirstAsync<T>(sql, parameters);
            return result;
        }

        public async Task<T> QueryFirstOrDefaultAsync<T, U>(string sql, U parameters, string connectionString = null)
        {
            using IDbConnection connection = new SqlConnection(!string.IsNullOrWhiteSpace(connectionString) ? connectionString : ConfigManager.EtmConnection);
            var result = await connection.QueryFirstOrDefaultAsync<T>(sql, parameters);
            return result;
        }

        public async Task<List<T>> LoadData<T, U>(string sql, U parameters, string connectionString = null)
        {
            using IDbConnection connection = new SqlConnection(!string.IsNullOrWhiteSpace(connectionString) ? connectionString : ConfigManager.EtmConnection);
            var rows = await connection.QueryAsync<T>(sql, parameters);
            return rows.ToList();
        }

        public async Task<int> ExecuteDataAsync<T>(string sql, T parameters, CommandType commandType = CommandType.Text, string connectionString = null)
        {
            using IDbConnection connection = new SqlConnection(!string.IsNullOrWhiteSpace(connectionString) ? connectionString : ConfigManager.EtmConnection);
            var rows = await connection.ExecuteAsync(sql, parameters, commandType: commandType);
            return rows;
        }

        public async Task<Tout> ExecuteScalarDataAsync<T, Tout>(string sql, T parameters, CommandType commandType = CommandType.Text, string connectionString = null)
        {
            using IDbConnection connection = new SqlConnection(!string.IsNullOrWhiteSpace(connectionString) ? connectionString : ConfigManager.EtmConnection);
            Tout tout = await connection.ExecuteScalarAsync<Tout>(sql, parameters, commandType: commandType);
            return tout;
        }
    }
}
