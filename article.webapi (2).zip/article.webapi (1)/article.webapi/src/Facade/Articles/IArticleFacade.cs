﻿using Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Facade.Articles
{
    public interface IArticleFacade
    {
        // TODO: Map to dto and return as Dto
        Task<IEnumerable<ArticleModel>> GetAll();
        Task<bool> AddNewArticle(ArticleModel articleModel);
        Task<bool> DeleteArticle(int articleid);
    }
}
