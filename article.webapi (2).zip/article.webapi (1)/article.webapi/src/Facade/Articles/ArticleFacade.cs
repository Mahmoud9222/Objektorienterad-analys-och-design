﻿using DataAccess.Articles;
using Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Facade.Articles
{
    public class ArticleFacade : IArticleFacade
    {
        public IArticleClient ArticleClient { get; }

        public ArticleFacade(IArticleClient articleClient)
        {
            ArticleClient = articleClient;
        }
        public async Task<IEnumerable<ArticleModel>> GetAll()
        {
            return await ArticleClient.GetAll();
        }

        public async Task<bool> AddNewArticle(ArticleModel articleModel)
        {
            return await ArticleClient.AddNewArticle(articleModel);
        }

        public async Task<bool> DeleteArticle(int articleid)
        {
           await ArticleClient.DeleteArticle(articleid);
            return true;
        }
    }
}
