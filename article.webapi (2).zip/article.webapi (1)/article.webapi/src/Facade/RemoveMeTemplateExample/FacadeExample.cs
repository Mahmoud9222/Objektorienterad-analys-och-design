﻿using System.Threading.Tasks;

namespace Facade.RemoveMeTemplateExample
{
    public class FacadeExample : IFacadeExample
    {
        public async Task<string> SayHello(string name)
        {
            return await Task.Run(() =>
            {
                return $"Hi {name}. Congratultions! Your project is upp and ready to run, you may remove this implementation from your project and do your own things :)";
            });
        }
    }
}
