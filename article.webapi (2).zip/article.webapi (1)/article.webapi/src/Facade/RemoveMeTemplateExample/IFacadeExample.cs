﻿using System.Threading.Tasks;

namespace Facade.RemoveMeTemplateExample
{
    public interface IFacadeExample
    {
        Task<string> SayHello(string name);
    }
}
