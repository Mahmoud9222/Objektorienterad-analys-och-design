﻿using DataAccess.Example;
using Model.Example;
using Operational.Performance;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Facade.RemoveMeTemplateExample.ClubExample
{
    public class ClubInfoNoEFExampleFacade : IClubInfoNoEFExampleFacade
    {
        private const string ClubCacheKey = "cachedClubData";
        public IClubNoEFExampleData ClubNoEFExampleData { get; }

        public ClubInfoNoEFExampleFacade(IClubNoEFExampleData clubNoEFExampleData)
        {
            ClubNoEFExampleData = clubNoEFExampleData;
        }

        public async Task<IEnumerable<ClubInfoExampleModel>> GetAll()
        {
            return await Task.Run(() =>
            {
                if (RestClientCacheManager.Contains(ClubCacheKey))
                {
                    return RestClientCacheManager.Get(ClubCacheKey) as IEnumerable<ClubInfoExampleModel>;
                }
                var data = ClubNoEFExampleData.GetAll();
                RestClientCacheManager.Set(ClubCacheKey, data, 0.02);
                return data;
            });
        }
    }
}
