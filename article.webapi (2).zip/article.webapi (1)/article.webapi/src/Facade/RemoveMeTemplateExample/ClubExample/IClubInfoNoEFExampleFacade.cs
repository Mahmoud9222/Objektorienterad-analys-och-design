﻿using Model.Example;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Facade.RemoveMeTemplateExample.ClubExample
{
    public interface IClubInfoNoEFExampleFacade
    {
        Task<IEnumerable<ClubInfoExampleModel>> GetAll();
    }
}
